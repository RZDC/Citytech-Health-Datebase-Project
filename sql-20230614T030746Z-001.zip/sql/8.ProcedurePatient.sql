
--Get Patient By CurrentUser
CREATE PROCEDURE GetPatientByCurrentUser
AS
BEGIN

  IF USER_NAME() LIKE 'Patient.%'
  BEGIN
	SELECT *
    FROM Patients
	--Show only patient name
    WHERE PatientName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));
  END
END;

--Get PrescriptionsRecord By CurrentUser
CREATE PROCEDURE GetPrescriptionsRecordByCurrentUser
AS
BEGIN

  IF USER_NAME() LIKE 'Patient.%'
  BEGIN
	SELECT *
    FROM PrescriptionsRecord
	--Show only patient name
    WHERE PatientName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));
  END
END;

--Get PrescriptionsRecord By CurrentUser
CREATE PROCEDURE GetAppointmentRecordByCurrentUser
AS
BEGIN

  IF USER_NAME() LIKE 'Patient.%'
  BEGIN
	SELECT *
    FROM AppointmentRecord
	--Show only patient name
    WHERE PatientName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));
  END
END;

--Get Payment Information By CurrentUser
CREATE PROCEDURE GetPaymentInformationByCurrentUser
AS
BEGIN

  IF USER_NAME() LIKE 'Patient.%'
  BEGIN
	SELECT *
    FROM PaymentInformation
	--Show only CardHolderName
    WHERE CardHolderName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));
  END
END;

--Update Payment Information
CREATE PROCEDURE UpdatePaymentInformation

    @NewCardCSV VARCHAR(10),
    @NewCardNumber VARCHAR(20)
AS
BEGIN
    UPDATE PaymentInformation
    SET CardCSV = @NewCardCSV,
        CardNumber = @NewCardNumber
    WHERE CardHolderName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));
END;



--Insert Prescription Record
CREATE PROCEDURE InsertPrescriptionRecord
  
  @PrescriptionsName VARCHAR(255),
  @DoctorName VARCHAR(255)
AS
BEGIN
  SET NOCOUNT ON;

  INSERT INTO PrescriptionsRecord (PrescriptionsName, DoctorName) 
  VALUES (@PrescriptionsName,@DoctorName);
END;



--DeletePatient
CREATE PROCEDURE DeletePatient
    @PatientName INT
AS
BEGIN
    DELETE FROM PatientsPrescriptionsStatus
    WHERE PatientName = @PatientName
END;







--Insert Appointment Record

CREATE PROCEDURE InsertAppointmentRecord
    @AppointmentDate DATE,
    @AppointmentType VARCHAR(50),
    @MeetingDoctorName VARCHAR(255),
    @TestResult VARCHAR(MAX)
AS
BEGIN
    INSERT INTO AppointmentRecord (AppointmentDate, AppointmentType, MeetingDoctorName, TestResult)
    VALUES (@AppointmentDate, @AppointmentType, @MeetingDoctorName,@TestResult)
END

