CREATE TRIGGER Tigger_Auto_Set_DoctorName_And_PatientsPrescriptionsStatusID
ON PatientsPrescriptionsStatus
INSTEAD OF INSERT
AS
BEGIN
  
DECLARE @DoctorName VARCHAR(255), 
        @PatientsPrescriptionsStatusID INT,
		@PatientsPrescriptionsStatus VARCHAR(50),
	    @PatientName VARCHAR(255),
	    @PrescriptionsName VARCHAR(255),
		@TreamentType VARCHAR(50);

SELECT @PatientsPrescriptionsStatus = PatientsPrescriptionsStatus,
	   @PatientName= PatientName,
	   @PrescriptionsName=PrescriptionsName,
	   @TreamentType =TreamentType
FROM inserted;

SET @DoctorName= SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()))
SET	@PatientsPrescriptionsStatusID= (SELECT COUNT(*) FROM PatientsPrescriptionsStatus) + 1 
 
  INSERT INTO PatientsPrescriptionsStatus (DoctorName,PatientsPrescriptionsStatusID, PatientsPrescriptionsStatus,PatientName,PrescriptionsName,TreamentType)
  VALUES (@DoctorName,@PatientsPrescriptionsStatusID, @PatientsPrescriptionsStatus,@PatientName,@PrescriptionsName,@TreamentType);
END;