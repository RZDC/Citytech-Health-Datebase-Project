
SELECT * FROM Patients;
SELECT * FROM AppointmentRecord;
SELECT * FROM Department;
SELECT * FROM Doctor;
SELECT * FROM Frontdeskstaff;
SELECT * FROM PaymentInformation;
SELECT * FROM PatientsPrescriptionsStatus;
SELECT * FROM PrescriptionsRecord;


--Show PatientAppointment
CREATE VIEW View_PatientAppointment AS
SELECT p.PatientName, a.AppointmentDate, a.AppointmentType
FROM Patients p
JOIN AppointmentRecord a ON p.PatientName = a.PatientName;

SELECT * FROM View_PatientAppointment


--Show Patient Prescriptions
CREATE VIEW View_PatientPrescriptions AS
SELECT p.PatientName, pr.PrescriptionsName, pr.OrderCreateDate
FROM Patients p
JOIN PrescriptionsRecord pr ON p.PatientName = pr.PatientName;

SELECT * FROM  View_PatientPrescriptions;


--Show Doctor Appointment
CREATE VIEW View_DoctorAppointment AS
SELECT d.DoctorName, a.AppointmentDate, a.AppointmentType
FROM Doctor d
JOIN AppointmentRecord a ON d.DoctorName = a.MeetingDoctorName;

SELECT * FROM  View_DoctorAppointment;


--Show Appointment Create by Frontdesk
CREATE VIEW View_FrontdeskCreateAppointment AS
SELECT f.FrontdeskstaffName, a.AppointmentDate, a.AppointmentType
FROM Frontdeskstaff f, AppointmentRecord a 
WHERE f.FrontdeskstaffID = a.AppointmentCreatorID

SELECT * FROM View_FrontdeskCreateAppointment;

--Show Appointment Create by Patients
CREATE VIEW View_PatientCreateAppointment AS
SELECT p.PatientName, a.AppointmentDate, a.AppointmentType
FROM Patients p
JOIN AppointmentRecord a ON p.PatientID = a.AppointmentCreatorID;

SELECT * FROM View_PatientCreateAppointment;

--Show Appointment Create by Doctors
CREATE VIEW View_DoctorCreateAppointment AS
SELECT d.DoctorName, a.AppointmentDate, a.AppointmentType
FROM Doctor d
JOIN AppointmentRecord a ON d.DoctorID = a.AppointmentCreatorID;

SELECT * FROM  View_DoctorCreateAppointment;

--Show Doctor Location
CREATE VIEW View_DoctorDepartment_Location AS
SELECT d.DoctorName, dep.DepartmentType, dep.DepartmentLocation
FROM Doctor d
JOIN Department dep ON d.DoctorDepartment = dep.DepartmentType;

SELECT * FROM View_DoctorDepartment_Location;


--Show Personal_Profile
CREATE VIEW View_Personal_Profile AS
SELECT *
FROM Patients s,PaymentInformation i
WHERE s.PatientName=i.CardHolderName

SELECT * FROM View_Personal_Profile
 
--Show Num of each card type
CREATE VIEW View_Count_Card_Type AS
SELECT CardType, Count(*)as Total_Num_Each_Card_Type
FROM PaymentInformation
Group by CardType;

SELECT * FROM View_Count_Card_Type


--Show Num of card type
CREATE VIEW View_Card_Type AS
SELECT DISTINCT CardType
FROM PaymentInformation;

SELECT * FROM View_Card_Type