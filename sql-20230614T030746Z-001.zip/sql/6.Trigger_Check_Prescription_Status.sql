CREATE TRIGGER Trigger_Check_Prescription_Status
ON PrescriptionsRecord
FOR INSERT
AS
BEGIN
  -- Check if there is a matching record in PatientsPrescriptionsStatus with 'Closed' status
  IF EXISTS (
      SELECT * 
      FROM inserted i 
      INNER JOIN PatientsPrescriptionsStatus p 
      ON i.PatientName = p.PatientName 
      AND i.PrescriptionsName = p.PrescriptionsName 
      WHERE i.PrescriptionsName = p.PrescriptionsName 
      AND i.PatientName = p.PatientName 
      AND p.PatientsPrescriptionsStatus = 'Closed'
  ) 
  BEGIN 
  --RAISERROR(TexT,Level,State)
    RAISERROR('Prescription record cannot be inserted because matching status is closed.', 16, 1)
    ROLLBACK TRANSACTION;
    RETURN;
  END

  -- Check if there is no matching record in PatientsPrescriptionsStatus
  IF NOT EXISTS (
      SELECT * 
      FROM inserted i 
      INNER JOIN PatientsPrescriptionsStatus p 
      ON i.PatientName = p.PatientName 
      AND i.PrescriptionsName = p.PrescriptionsName 
      WHERE i.PrescriptionsName = p.PrescriptionsName 
      AND i.PatientName = p.PatientName 
  ) 
  BEGIN
    RAISERROR('No matching Prescription Permission', 16, 1)
    ROLLBACK TRANSACTION;
    RETURN;
  END 

  -- Check if there is a matching record in PatientsPrescriptionsStatus with 'Open' status
  IF EXISTS (
      SELECT * 
      FROM inserted i 
      INNER JOIN PatientsPrescriptionsStatus p 
      ON i.PatientName = p.PatientName 
      AND i.PrescriptionsName = p.PrescriptionsName 
      WHERE i.PrescriptionsName = p.PrescriptionsName 
      AND i.PatientName = p.PatientName 
      AND p.PatientsPrescriptionsStatus = 'Open'
  )
  BEGIN
    RETURN;
  END
END;