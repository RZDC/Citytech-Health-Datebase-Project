CREATE TRIGGER Tigger_Auto_Set_ID_And_Date_And_Name
ON PrescriptionsRecord
INSTEAD OF INSERT
AS
BEGIN
  
  DECLARE @PatientName VARCHAR(255), 
          @DoctorName VARCHAR(255), 
		  @PrescriptionsName VARCHAR(255), 
		  @OrderCreateDate DATE,
		  @PrescriptionsRecordID INT;

  SET @PrescriptionsRecordID = (SELECT COUNT(*) FROM PrescriptionsRecord) + 1;

  SELECT @PrescriptionsName = PrescriptionsName FROM inserted;
  
  SET @OrderCreateDate = GETDATE();

IF(USER_NAME() LIKE 'Patient.%')
BEGIN
  SELECT @PatientName = SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME())), 
         @DoctorName = DoctorName FROM inserted;
END

ELSE IF(USER_NAME() LIKE 'Doctor.%')
BEGIN
  SELECT @DoctorName = SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME())), 
         @PatientName = PatientName FROM inserted;
END


ELSE IF(USER_NAME() LIKE 'Frontdeskstaff.%')
BEGIN
  SELECT @DoctorName = DoctorName,   
		 @PatientName = PatientName FROM inserted;
         
END
  
  INSERT INTO PrescriptionsRecord (PrescriptionsRecordID, PatientName, DoctorName, PrescriptionsName, OrderCreateDate)
  VALUES (@PrescriptionsRecordID, @PatientName, @DoctorName, @PrescriptionsName, @OrderCreateDate);
END;
