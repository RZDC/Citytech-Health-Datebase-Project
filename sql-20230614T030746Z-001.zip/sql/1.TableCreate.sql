CREATE TABLE Patients (
  PatientID INT PRIMARY KEY,
  PatientName VARCHAR(255) NOT NULL,
  PatientBirthday DATE,
  PatientsGender VARCHAR(10),
);

CREATE TABLE PaymentInformation (
  CardType VARCHAR(50) NOT NULL,
  CardHolderName VARCHAR(255) NOT NULL PRIMARY KEY,
  CardCSV VARCHAR(10) NOT NULL,
  CardNumber VARCHAR(20) NOT NULL
);

CREATE TABLE Doctor (
  DoctorName VARCHAR(255) NOT NULL,
  DoctorID INT NOT NULL PRIMARY KEY,
  DoctorDepartment VARCHAR(50) NOT NULL
);

CREATE TABLE Frontdeskstaff (
  FrontdeskstaffName VARCHAR(255) NOT NULL,
  FrontdeskstaffID INT NOT NULL PRIMARY KEY,
  
);

CREATE TABLE PrescriptionsRecord (
  PrescriptionsRecordID INT NOT NULL PRIMARY KEY,
  PrescriptionsName VARCHAR(255) NOT NULL,
  OrderCreateDate DATE NOT NULL,
  PatientName VARCHAR(255) NOT NULL,
  DoctorName VARCHAR(255) NOT NULL
);

CREATE TABLE AppointmentRecord (
  AppointmentID INT NOT NULL PRIMARY KEY,
  AppointmentDate DATE NOT NULL,
  AppointmentType VARCHAR(50) NOT NULL,
  MeetingDoctorName VARCHAR(255) NOT NULL,
  PatientName VARCHAR(255) NOT NULL,
  TestResult VARCHAR(MAX),
  AppointmentCreateDate DATE NOT NULL,
  AppointmentCreatorID INT NOT NULL
);

CREATE TABLE PatientsPrescriptionsStatus(
PatientsPrescriptionsStatusID INT PRIMARY KEY,
PatientsPrescriptionsStatus VARCHAR(50) NOT NULL,
PatientName VARCHAR(255) NOT NULL,
DoctorName VARCHAR(255) NOT NULL,
PrescriptionsName VARCHAR(255) NOT NULL,
TreamentType VARCHAR(50) NOT NULL

);

CREATE TABLE Department(
DepartmentType VARCHAR(50) NOT NULL PRIMARY KEY,
DepartmentLocation VARCHAR(50) NOT NULL,
DepartmentDirector VARCHAR(50) NOT NULL
);



