CREATE TRIGGER Tigger_Auto_Set_AppointmentRecordID_AppointmentRecordDate_AppointmentRecordCreateID
ON AppointmentRecord
INSTEAD OF INSERT
AS
BEGIN
DECLARE @AppointmentID INT,
		@AppointmentCreateDate DATE, 
		@AppointmentCreateID INT,
		@AppointmentDate DATE,
	    @AppointmentType VARCHAR(50),
		@MeetingDoctorName VARCHAR(255),
		@TestResult VARCHAR(MAX),
		@PatientName VARCHAR(255)
--Include data that just insert
SELECT  @AppointmentDate=AppointmentDate,
		@AppointmentType=AppointmentType,
		@TestResult=TestResult
FROM inserted;

--Value for AppointmentID
SELECT @AppointmentID = ISNULL(MAX(AppointmentID), 0) + 1 FROM AppointmentRecord;

--Value for AppointmentCreateDate
SET @AppointmentCreateDate = GETDATE()

IF(USER_NAME() LIKE 'Patient.%')
BEGIN

SELECT @MeetingDoctorName=MeetingDoctorName FROM inserted;

--Value for AppointmentCreateID
SELECT @AppointmentCreateID = PatientID FROM Patients WHERE PatientName=SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()))

--Value for PatientName
SET @PatientName= SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()))
END

Else IF(USER_NAME() LIKE 'Doctor.%')
BEGIN

SELECT @PatientName = PatientName FROM inserted;

--Value for AppointmentCreateID
SELECT @AppointmentCreateID = DoctorID FROM Doctor WHERE DoctorName=SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()))

--Value for DoctorName
SET @MeetingDoctorName= SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()))
END

Else IF(USER_NAME() LIKE 'Frontdeskstaff.%')
BEGIN

SELECT @PatientName = PatientName FROM inserted;
SELECT @MeetingDoctorName=MeetingDoctorName FROM inserted;
--Value for AppointmentCreateID
SELECT @AppointmentCreateID = FrontdeskstaffID FROM Frontdeskstaff WHERE FrontdeskstaffName=SUBSTRING(USER_NAME(), LEN('Frontdeskstaff.') + 1, LEN(USER_NAME()))

--Value for DoctorName

END



  INSERT INTO AppointmentRecord (AppointmentID, AppointmentDate, AppointmentType, MeetingDoctorName, PatientName, TestResult, AppointmentCreateDate, AppointmentCreatorID)
  VALUES (@AppointmentID, @AppointmentDate, @AppointmentType, @MeetingDoctorName, @PatientName, @TestResult, @AppointmentCreateDate, @AppointmentCreateID)

END;