--PROCEDURE For Doctor

--Get Payment Information By CurrentUser
CREATE PROCEDURE GetAppointmentRecordByCurrentDoctor
AS
BEGIN

  IF USER_NAME() LIKE 'Doctor.%'
  BEGIN
	SELECT *
    FROM AppointmentRecord
	--Show only CardHolderName
    WHERE MeetingDoctorName = SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()));
  END
END;



CREATE PROCEDURE InsertAppointmentRecordByDoctor
    @AppointmentDate DATE,
    @AppointmentType VARCHAR(50),
    @PatientName VARCHAR(255),
    @TestResult VARCHAR(MAX)
AS
BEGIN
    INSERT INTO AppointmentRecord (AppointmentDate, AppointmentType, PatientName, TestResult)
    VALUES (@AppointmentDate, @AppointmentType, @PatientName,@TestResult)
END;


CREATE PROCEDURE InsertPrescriptionRecordByDoctor
  
  @PrescriptionsName VARCHAR(255),
  @PatientName VARCHAR(255)
AS
BEGIN


  INSERT INTO PrescriptionsRecord (PrescriptionsName, PatientName) 
  VALUES (@PrescriptionsName,@PatientName);
END;


--Get Doctor Information
CREATE PROCEDURE GetDoctorByCurrentUser
AS
BEGIN

  IF USER_NAME() LIKE 'Doctor.%'
  BEGIN
	SELECT *
    FROM Doctor
	--Show only Doctor name
    WHERE DoctorName = SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()));
  END
END;



CREATE PROCEDURE InsertPatientsPrescriptionsStatus
   
    @PatientsPrescriptionsStatus VARCHAR(50),
    @PatientName VARCHAR(255),
    @PrescriptionsName VARCHAR(255),
    @TreamentType VARCHAR(50)
AS
BEGIN
	

    INSERT INTO PatientsPrescriptionsStatus (PatientsPrescriptionsStatus, PatientName, PrescriptionsName, TreamentType)
    VALUES (@PatientsPrescriptionsStatus, @PatientName,@PrescriptionsName, @TreamentType)
END;



CREATE PROCEDURE UpdatePatientsPrescriptionsStatus

     @PatientsPrescriptionsStatus VARCHAR(50),
	 @PatientName VARCHAR(255),
	 @PrescriptionsName VARCHAR(50)
AS
BEGIN
IF @PatientsPrescriptionsStatus IN ('Closed', 'Open')
    BEGIN
    UPDATE PatientsPrescriptionsStatus
	SET PatientsPrescriptionsStatus = @PatientsPrescriptionsStatus
	WHERE DoctorName = SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()))
	And @PrescriptionsName=PrescriptionsName
	And @PatientName=PatientName
END
ELSE
    BEGIN
     
        RAISERROR('Invalid value for PatientsPrescriptionsStatus.', 16, 1)
    
END
END;



CREATE PROCEDURE InsertAppointmentRecordByFrontdeskstaff
    @AppointmentDate DATE,
    @AppointmentType VARCHAR(50),
    @PatientName VARCHAR(255),
    @TestResult VARCHAR(MAX),
	@MeetingDoctorName VARCHAR(255)
AS
BEGIN
    INSERT INTO AppointmentRecord (AppointmentDate, AppointmentType, PatientName, TestResult,MeetingDoctorName)
    VALUES (@AppointmentDate, @AppointmentType, @PatientName,@TestResult,@MeetingDoctorName)
END;



CREATE PROCEDURE InsertPrescriptionRecordByFrontdeskstaff
  
  @PrescriptionsName VARCHAR(255),
  @PatientName VARCHAR(255),
  @DoctorName VARCHAR(255)
AS
BEGIN


  INSERT INTO PrescriptionsRecord (PrescriptionsName, PatientName, DoctorName) 
  VALUES (@PrescriptionsName,@PatientName, @DoctorName);
END;