
--Patients Role 
CREATE ROLE Role_PatientsView;
GRANT EXECUTE ON dbo.GetPatientByCurrentUser TO Role_PatientsView
GRANT EXECUTE ON dbo.GetPrescriptionsRecordByCurrentUser TO Role_PatientsView
GRANT EXECUTE ON dbo.GetAppointmentRecordByCurrentUser TO Role_PatientsView
GRANT EXECUTE ON dbo.GetPaymentInformationByCurrentUser TO Role_PatientsView
GRANT EXECUTE ON dbo.UpdatePaymentInformation TO Role_PatientsView
GRANT EXECUTE ON dbo.InsertPrescriptionRecord TO Role_PatientsView
GRANT EXECUTE ON dbo.InsertAppointmentRecord TO Role_PatientsView
--User
CREATE USER [Patient.John Smith] without login;
EXEC sp_addrolemember 'Role_PatientsView', 'Patient.John Smith';

--Test

EXECUTE AS USER ='Patient.John Smith';
SELECT SUBSTRING(USER_NAME(), LEN('Patient.') + 1, LEN(USER_NAME()));

--Get Patient Information By Current User
EXEC GetPatientByCurrentUser;


--Get/Update Patient Information By Current User
EXEC GetPaymentInformationByCurrentUser;

EXEC UpdatePaymentInformation '223', '121232131226';

--Get/Insert Prescriptions Record By Current User
EXEC GetPrescriptionsRecordByCurrentUser;

EXEC InsertPrescriptionRecord
	--No matching Prescription Permission
  @PrescriptionsName = 'Painkillers',
  @DoctorName = 'Dr. Lee';
EXEC InsertPrescriptionRecord
	--Sucess
  @PrescriptionsName = 'Antibiotics',
  @DoctorName = 'Dr. Johnson';
EXEC InsertPrescriptionRecord
	--Prescription record cannot be inserted because matching status is closed
  @PrescriptionsName = 'Antibiotics A',
  @DoctorName = 'Dr. Johnson';

--Get/Insert Appointment Record By Current User
EXEC GetAppointmentRecordByCurrentUser;
EXEC InsertAppointmentRecord 
@AppointmentDate ='2023-05-16',
@AppointmentType ='Blood tests',
@MeetingDoctorName ='Dr. Johnson',
@TestResult='normal';
REVERT;


Select * from PrescriptionsRecord;
DELETE FROM PrescriptionsRecord
WHERE PrescriptionsRecordID=21;



Select * from PaymentInformation
DELETE FROM PaymentInformation
WHERE CardCSV =53;
	

Select * from AppointmentRecord
DELETE FROM  AppointmentRecord
WHERE AppointmentDate ='2023-05-16';










--Doctor Role 
CREATE ROLE Role_DoctorView;
GRANT SELECT ON dbo.Patients TO Role_DoctorView;
GRANT SELECT ON dbo.Department TO Role_DoctorView;
GRANT SELECT ON dbo.PatientsPrescriptionsStatus TO Role_DoctorView;
GRANT SELECT ON dbo.PrescriptionsRecord TO Role_DoctorView;
GRANT EXECUTE ON dbo.GetAppointmentRecordByCurrentDoctor TO Role_DoctorView;
GRANT EXECUTE ON dbo.InsertAppointmentRecordByDoctor TO Role_DoctorView;
GRANT EXECUTE ON dbo.InsertPrescriptionRecordByDoctor TO Role_DoctorView;
GRANT EXECUTE ON dbo.GetDoctorByCurrentUser TO Role_DoctorView;
GRANT EXECUTE ON dbo.InsertPatientsPrescriptionsStatus TO Role_DoctorView;
GRANT EXECUTE ON dbo.UpdatePatientsPrescriptionsStatus TO Role_DoctorView;
--Doctor
CREATE USER [Doctor.John Smith] without login;
EXEC sp_addrolemember 'Role_DoctorView', 'Doctor.John Smith';



EXECUTE AS USER ='Doctor.John Smith';
--Doctor Name
SELECT SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()));

--Get/Insert Appointment Record
EXEC GetAppointmentRecordByCurrentDoctor;

EXEC InsertAppointmentRecordByDoctor
@AppointmentDate ='2023-05-16',
@AppointmentType ='Blood tests',
@PatientName ='Jane Doe',
@TestResult='normal';


--Insert Prescriptions Record By Doctor
EXEC InsertPrescriptionRecordByDoctor
  @PrescriptionsName = 'Antibiotics',
  @PatientName = 'Tom Brown';

--Get Doctor Information
EXEC GetDoctorByCurrentUser;

--Insert/Update PatientsPrescriptionsStatus
EXEC InsertPatientsPrescriptionsStatus
 
    @PatientsPrescriptionsStatus='Open',
    @PatientName='John',
    @PrescriptionsName='Antibiotics',
    @TreamentType='Infections'

EXEC UpdatePatientsPrescriptionsStatus
    @PatientsPrescriptionsStatus = 'Closed',
    @PrescriptionsName = 'Antibiotics',
	@PatientName='John'
REVERT;



Select * from PatientsPrescriptionsStatus
WHERE DoctorName = SUBSTRING(USER_NAME(), LEN('Doctor.') + 1, LEN(USER_NAME()))
	
Select * from PatientsPrescriptionsStatus
DELETE FROM PatientsPrescriptionsStatus
WHERE PatientsPrescriptionsStatusID=21;

Select * from PrescriptionsRecord
DELETE FROM PrescriptionsRecord
WHERE PrescriptionsRecordID=21;








--Frontdesk staff

CREATE ROLE Role_FrontdeskstaffView;
GRANT SELECT ON dbo.Patients TO Role_FrontdeskstaffView;
GRANT SELECT ON dbo.Department TO Role_FrontdeskstaffView;
GRANT SELECT ON dbo.PatientsPrescriptionsStatus TO Role_FrontdeskstaffView;
GRANT SELECT ON dbo.PrescriptionsRecord TO Role_FrontdeskstaffView;
GRANT SELECT ON dbo.Doctor TO Role_FrontdeskstaffView;
GRANT SELECT ON dbo.AppointmentRecord TO Role_FrontdeskstaffView;
GRANT EXECUTE ON dbo.InsertAppointmentRecordByFrontdeskstaff TO Role_FrontdeskstaffView;
GRANT EXECUTE ON dbo.InsertPrescriptionRecordByFrontdeskstaff TO Role_FrontdeskstaffView;
CREATE USER [Frontdeskstaff.John Doe] without login; 
EXEC sp_addrolemember 'Role_FrontdeskstaffView', 'Frontdeskstaff.John Doe';


EXECUTE AS USER = 'Frontdeskstaff.John Doe'
SELECT SUBSTRING(USER_NAME(), LEN('Frontdeskstaff.') + 1, LEN(USER_NAME()));

--Insert AppointmentRecord By Frontdeskstaff
EXEC InsertAppointmentRecordByFrontdeskstaff
@AppointmentDate ='2023-05-16',
@AppointmentType ='Blood tests',
@PatientName ='Smit Doe',
@TestResult='normal',
@MeetingDoctorName='Tom';



EXEC InsertPrescriptionRecordByFrontdeskstaff
@PrescriptionsName = 'Antibiotics',
@PatientName = 'Tom Brown',
@DoctorName = 'David Lee';
REVERT;


Select * From PrescriptionsRecord;
Select * From Doctor;
Select * From AppointmentRecord;
DELETE FROM AppointmentRecord
WHERE AppointmentID=21;
Select * From PrescriptionsRecord;
DELETE FROM PrescriptionsRecord
WHERE PrescriptionsRecordID=21;